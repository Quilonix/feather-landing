// First-paint theme hint for the popup, and nothing else.
//
// This is a classic (non-module) script loaded from <head>, so it runs
// synchronously before the body is painted. That matters because Manifest V3
// forbids inline scripts, and a module script is always deferred - either would
// paint a light popup for a frame before the theme could be applied.
//
// It can only consult the system colour scheme, since chrome.storage is async
// and cannot be read before first paint. popup.js corrects this a moment later
// from the stored preference, which only differs for someone who has explicitly
// chosen Light or Dark against their system setting.
//
// Deliberately duplicates nothing but the media query itself; all real theme
// logic lives in src/theme.js.
(function () {
  try {
    var dark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    document.documentElement.setAttribute("data-fd-theme", dark ? "dark" : "light");
  } catch (_) {
    document.documentElement.setAttribute("data-fd-theme", "light");
  }
})();
