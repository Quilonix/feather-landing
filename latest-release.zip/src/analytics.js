// Anonymous, privacy-respecting usage analytics via PostHog Cloud's free
// tier (1M events/month free forever, no card required). We call its plain
// HTTP capture endpoint directly with fetch() - no remote script is loaded,
// which keeps this compliant with Manifest V3's "no remotely-hosted code"
// rule (only local, reviewable code runs in the extension).
//
// PostHog project: id 243959. The key below is PostHog's public "capture"
// token - it can only send events in, never read data out, so it's safe to
// ship inside the extension bundle (this is the standard/intended way
// PostHog client-side keys work, same as posting from a public website).
//
// Privacy: we only ever send an anonymous random ID (generated once,
// stored in chrome.storage.local, never tied to any account/email) plus
// non-identifying event properties (file extension, token-savings
// percentage, which site the conversion happened on). We NEVER send
// filenames, file contents, or converted Markdown text. Since this is now
// enabled, disclose "usage analytics" in the Chrome Web Store's Privacy
// Practices tab before publishing - Chrome requires that disclosure for
// any data collection, even fully anonymous.
const POSTHOG_API_KEY = "phc_yNzmHYEW8dWXxZMabq8aDFpFNtSgUiev8VxkYgHYdpFs";
// This project lives in PostHog's EU region (dashboard URL is
// eu.posthog.com), so events MUST go to the EU ingestion host. Sending to
// the US host silently drops every event - no error, just nothing shows up
// in the project. This was the actual root cause of "nothing appears."
const POSTHOG_HOST = "https://eu.i.posthog.com";

let cachedDistinctId = null;

async function getDistinctId() {
  if (cachedDistinctId) return cachedDistinctId;
  const stored = await chrome.storage.local.get("fdDistinctId");
  if (stored.fdDistinctId) {
    cachedDistinctId = stored.fdDistinctId;
    return cachedDistinctId;
  }
  const id = crypto.randomUUID();
  await chrome.storage.local.set({ fdDistinctId: id });
  cachedDistinctId = id;
  return id;
}

export async function trackEvent(eventName, properties = {}) {
  if (!POSTHOG_API_KEY || POSTHOG_API_KEY.startsWith("REPLACE_WITH")) return;
  try {
    const distinctId = await getDistinctId();
    await fetch(`${POSTHOG_HOST}/capture/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: POSTHOG_API_KEY,
        event: eventName,
        distinct_id: distinctId,
        properties,
      }),
    });
  } catch (_) {
    // Analytics must never break the actual feature - swallow all errors.
  }
}

// "Active users" (e.g. daily/weekly active in PostHog's Insights) can only
// be computed from events that fire on usage, not just on conversion - a
// user who opens the bubble but doesn't convert anything that day would
// otherwise be invisible. This fires a lightweight "extension_active"
// event at most once per calendar day per browser (deduped via
// chrome.storage so we don't spam an event on every page load), whenever
// the floating bubble is injected on a supported site. That's enough for
// PostHog's Insights to build "active users" and "active installs" charts
// without needing any extra properties beyond the anonymous distinct_id.
export async function trackDailyActive() {
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD, local calendar day is fine for this purpose
  const stored = await chrome.storage.local.get("fdLastActiveDay");
  if (stored.fdLastActiveDay === today) return;
  await chrome.storage.local.set({ fdLastActiveDay: today });
  await trackEvent("extension_active", { hostname: location.hostname });
}
