// Theme resolution, shared by the injected widget and the toolbar popup.
//
// ── What Chrome actually exposes ─────────────────────────────────────────────
// There is no extension API that reports Chrome's own light/dark appearance.
// Chrome's Settings > Appearance > Mode changes the browser UI only; the
// Chromium issue for communicating it to page content (crbug 332328864,
// "Appearance Mode changes (light/dark) are not communicated to web content")
// is still how it behaves, so a content script cannot read it.
//
// The signal that IS available is the `prefers-color-scheme` media query, which
// reports the operating system's colour scheme. On Windows and macOS Chrome's
// own UI follows that same OS setting by default, so for the ordinary case -
// user turns on dark mode, Chrome goes dark - matching prefers-color-scheme
// gives exactly the requested behaviour: dark Chrome, dark widget.
//
// The gap is a user who sets Chrome's Mode to Light or Dark explicitly, against
// the OS. Nothing can detect that, so it is covered the only way it can be: a
// manual Light/Dark override in settings. "Auto" (the default) follows the
// system, and live-updates when the system flips without needing a reload.

export const THEME_MODES = ["auto", "light", "dark"];
export const DEFAULT_THEME_MODE = "auto";

// The attribute the stylesheets key off. Tokens live under
// [data-fd-theme="dark"] rather than inside an @media block so that an explicit
// override can win over the system preference; @media cannot be overridden from
// script.
export const THEME_ATTR = "data-fd-theme";

const DARK_QUERY = "(prefers-color-scheme: dark)";

// Pure, so it can be tested without a DOM: given the stored preference and what
// the system reports, which theme applies.
export function resolveTheme(mode, systemPrefersDark) {
  if (mode === "light" || mode === "dark") return mode;
  // Anything unrecognised (null on first run, or a value from a newer version)
  // falls back to following the system rather than guessing a fixed theme.
  return systemPrefersDark ? "dark" : "light";
}

export function systemPrefersDark(win = globalThis) {
  try {
    return Boolean(win.matchMedia && win.matchMedia(DARK_QUERY).matches);
  } catch (_) {
    // matchMedia is missing in some embedding contexts; light is the safer
    // default because the widget's light palette is legible on more pages.
    return false;
  }
}

export function applyTheme(el, theme) {
  if (!el) return;
  el.setAttribute(THEME_ATTR, theme === "dark" ? "dark" : "light");
}

// Calls back whenever the system colour scheme changes. Returns an unsubscribe
// function. addEventListener("change") is the current API; addListener is the
// deprecated form still needed by older engines, so both are attempted.
export function watchSystemTheme(onChange, win = globalThis) {
  let mql;
  try {
    mql = win.matchMedia && win.matchMedia(DARK_QUERY);
  } catch (_) {
    return () => {};
  }
  if (!mql) return () => {};

  const handler = (e) => onChange(Boolean(e.matches));
  if (typeof mql.addEventListener === "function") {
    mql.addEventListener("change", handler);
    return () => mql.removeEventListener("change", handler);
  }
  if (typeof mql.addListener === "function") {
    mql.addListener(handler);
    return () => mql.removeListener(handler);
  }
  return () => {};
}

// Convenience wrapper: applies the resolved theme now and keeps it in sync with
// the system while the mode stays "auto". Returns an unsubscribe function.
export function bindTheme(el, mode, win = globalThis) {
  applyTheme(el, resolveTheme(mode, systemPrefersDark(win)));
  if (mode !== "auto" && THEME_MODES.includes(mode)) return () => {};
  return watchSystemTheme((prefersDark) => {
    applyTheme(el, resolveTheme(mode, prefersDark));
  }, win);
}
