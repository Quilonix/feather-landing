// Feather toolbar popup.
// Storage schema (chrome.storage.sync):
//   disabledAll: boolean - hide widget on every supported site
//   disabledSites: { [hostname]: true } - per-site overrides
//   theme: "auto" | "light" | "dark" - Auto follows the system colour scheme
//
// Loaded as a module (see popup.html) so the theme logic is imported from
// src/theme.js rather than reimplemented here. popup-theme-boot.js handles only
// the pre-paint hint, because a module script is deferred.
import { DEFAULT_THEME_MODE, THEME_MODES, bindTheme } from "./src/theme.js";

const AI_SITE_PATTERNS = [
  "claude.ai",
  "chatgpt.com",
  "chat.openai.com",
  "gemini.google.com",
  "copilot.microsoft.com",
  "www.perplexity.ai",
  "poe.com",
  "chat.mistral.ai",
  "huggingface.co",
  "character.ai",
  "beta.character.ai",
  "you.com",
  "grok.com",
  "x.com",
  "chat.deepseek.com",
  "chat.qwen.ai",
  "www.kimi.com",
  "kimi.moonshot.cn",
  "www.meta.ai",
  "pi.ai",
  "coral.cohere.com",
  "chat.groq.com",
  "chat.z.ai",
  "chat.reka.ai",
  "duckduckgo.com",
];

function isSupportedSite(hostname) {
  return AI_SITE_PATTERNS.some(
    (p) => hostname === p || hostname.endsWith("." + p)
  );
}

async function getStorage() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(
      { disabledAll: false, disabledSites: {}, theme: DEFAULT_THEME_MODE },
      resolve
    );
  });
}

async function setStorage(patch) {
  return new Promise((resolve) => {
    chrome.storage.sync.set(patch, resolve);
  });
}

async function getActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) =>
      resolve(tabs[0] || null)
    );
  });
}

// ---- render per-site disabled list ----
function renderSiteList(disabledSites) {
  const el = document.getElementById("site-list-el");
  const hosts = Object.keys(disabledSites).filter((h) => disabledSites[h]);
  if (hosts.length === 0) {
    el.innerHTML = '<div class="empty-msg">No sites disabled</div>';
    return;
  }
  el.innerHTML = hosts
    .map(
      (h) =>
        `<div class="site-item"><span>${h}</span><button class="remove-site" data-host="${h}" title="Re-enable on ${h}">&times;</button></div>`
    )
    .join("");
  el.querySelectorAll(".remove-site").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const { disabledSites } = await getStorage();
      delete disabledSites[btn.dataset.host];
      await setStorage({ disabledSites });
      renderSiteList(disabledSites);
    });
  });
}

// ---- theme selector ----
// bindTheme applies the resolved theme now and, while the mode is "auto", keeps
// following the system if it changes while the popup is open. Writing to
// storage.sync is what makes every open tab's widget update too, via the
// storage.onChanged listener in content.js.
function setUpThemeSelector(initialMode) {
  const seg = document.getElementById("theme-seg");
  const hint = document.getElementById("theme-hint");
  let unbind = () => {};

  const paint = (mode) => {
    seg.querySelectorAll("button[data-theme]").forEach((b) => {
      b.setAttribute("aria-pressed", String(b.dataset.theme === mode));
    });
    hint.textContent = mode === "auto"
      ? "Auto follows your system light/dark setting, the same one Chrome's own theme follows."
      : `Always ${mode}, regardless of your system setting.`;
    unbind();
    unbind = bindTheme(document.documentElement, mode);
  };

  paint(THEME_MODES.includes(initialMode) ? initialMode : DEFAULT_THEME_MODE);

  seg.addEventListener("click", async (e) => {
    const btn = e.target.closest("button[data-theme]");
    if (!btn) return;
    const mode = btn.dataset.theme;
    paint(mode);
    await setStorage({ theme: mode });
  });
}

// ---- main ----
(async () => {
  const tab = await getActiveTab();
  let tabUrl = null;
  try { tabUrl = tab && tab.url ? new URL(tab.url) : null; } catch (_) {}
  const hostname = tabUrl ? tabUrl.hostname : null;
  const onAiSite = hostname ? isSupportedSite(hostname) : false;

  const { disabledAll, disabledSites, theme } = await getStorage();

  setUpThemeSelector(theme);

  const onSiteSection = document.getElementById("on-site-section");
  const manageSection = document.getElementById("manage-section");
  const managePanel = document.getElementById("manage-panel");
  const manageLink = document.getElementById("manage-link");

  const toggleSiteInput = document.getElementById("toggle-site");
  const toggleAllInput = document.getElementById("toggle-all");
  const disableSiteLabel = document.getElementById("disable-site-label");
  const disableSiteHost = document.getElementById("disable-site-host");

  // "Disabled" checkbox is checked = feature is OFF for that scope
  function applyDisabledStyle(input, isDisabled) {
    if (isDisabled) {
      input.checked = true;
      input.classList.add("is-disabled");
    } else {
      input.checked = false;
      input.classList.remove("is-disabled");
    }
  }

  // Set initial visual state
  applyDisabledStyle(toggleAllInput, disabledAll);

  if (onAiSite && hostname) {
    onSiteSection.style.display = "";
    disableSiteLabel.textContent = `Disable for this site`;
    disableSiteHost.textContent = hostname;
    applyDisabledStyle(toggleSiteInput, !!disabledSites[hostname]);

    toggleSiteInput.addEventListener("change", async () => {
      const { disabledSites } = await getStorage();
      if (toggleSiteInput.checked) {
        disabledSites[hostname] = true;
        toggleSiteInput.classList.add("is-disabled");
      } else {
        delete disabledSites[hostname];
        toggleSiteInput.classList.remove("is-disabled");
      }
      await setStorage({ disabledSites });
      // Notify content script on the active tab
      chrome.tabs.sendMessage(tab.id, { type: "fd_settings_changed" }).catch(() => {});
    });
  } else {
    // Not an AI site - show "Manage sites" option
    manageSection.style.display = "";
    renderSiteList(disabledSites);
    manageLink.addEventListener("click", () => {
      managePanel.classList.toggle("open");
      manageLink.textContent = managePanel.classList.contains("open")
        ? "Hide ›"
        : "Manage where Feather appears ›";
    });
  }

  toggleAllInput.addEventListener("change", async () => {
    const isDisabled = toggleAllInput.checked;
    toggleAllInput.classList.toggle("is-disabled", isDisabled);
    await setStorage({ disabledAll: isDisabled });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, { type: "fd_settings_changed" }).catch(() => {});
    }
  });
})();
