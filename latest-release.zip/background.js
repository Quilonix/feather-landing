// Minimal service worker. All document conversion happens locally in the
// content script's page context - this file only records install time and
// fires one anonymous "extension_installed" analytics event (see
// src/analytics.js for what is/isn't sent - no filenames or content, ever).
import { trackEvent } from "./src/analytics.js";

chrome.runtime.onInstalled.addListener((details) => {
  chrome.storage.local.set({ fdInstalledAt: Date.now() });
  if (details.reason === "install") {
    trackEvent("extension_installed");
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "open_tab" && msg.url) {
    chrome.tabs.create({ url: msg.url });
    sendResponse({ ok: true });
  }
});
